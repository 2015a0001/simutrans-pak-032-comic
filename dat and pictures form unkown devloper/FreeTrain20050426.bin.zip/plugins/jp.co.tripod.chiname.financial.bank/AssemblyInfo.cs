using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("FreeTrain bank plug-in")]
[assembly: AssemblyDescription("The bank ")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("c477(chiname@lycos.jp)")]
[assembly: AssemblyProduct("FreeTrain")]
[assembly: AssemblyCopyright("(C)Copyright by c477(chiname), 2003")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]		


[assembly: AssemblyVersion("1.0.*")]

[assembly: AssemblyDelaySign(false)]
[assembly: AssemblyKeyFile("")]
[assembly: AssemblyKeyName("")]
